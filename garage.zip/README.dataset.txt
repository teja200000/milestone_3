# garage > 2022-11-21 1:21am
https://universe.roboflow.com/njit-mhr5p/garage-co4hb

Provided by a Roboflow user
License: CC BY 4.0

